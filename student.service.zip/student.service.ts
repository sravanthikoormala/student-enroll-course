import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  url = "http://localhost:8085/student/";

  constructor(private http:HttpClient) { }


  signupstudent(student:any)
  {
    return this.http.post(this.url,student);
  }
  getAllStudents()
  {
    return this.http.get(this.url);
  }
  findStudentById(id:number)
  {
    return this.http.get(this.url+id);
  }
  addStudent(student:any)
  {
    return this.http.post(this.url,student);
  }
  updateStudent(student:any)
  {
    return this.http.put(this.url,student);
  }
  deleteStudent(id:number)
  {
    return this.http.delete(this.url+id);
  }
}
