package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Upload")
public class Upload {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
private Integer id;
private Integer teacherId;
private Integer courseId;
public Upload(Integer id, Integer teacherId, Integer courseId) {
	super();
	this.id = id;
	this.teacherId = teacherId;
	this.courseId = courseId;
}
public Upload(Integer teacherId, Integer courseId) {
	super();
	this.teacherId = teacherId;
	this.courseId = courseId;
}
public Upload() {
	super();
}
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public Integer getTeacherId() {
	return teacherId;
}
public void setTeacherId(Integer teacherId) {
	this.teacherId = teacherId;
}
public Integer getCourseId() {
	return courseId;
}
public void setCourseId(Integer courseId) {
	this.courseId = courseId;
}
@Override
public String toString() {
	return "Upload [id=" + id + ", teacherId=" + teacherId + ", courseId=" + courseId + "]";
}


}
