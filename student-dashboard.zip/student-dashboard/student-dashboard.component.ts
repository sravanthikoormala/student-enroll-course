import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { CoursesService } from '../courses.service';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-dashboard',
  templateUrl: './student-dashboard.component.html',
  styleUrls: ['./student-dashboard.component.css']
})
export class StudentDashboardComponent implements OnInit {
  closeResult: string="";
studentList:any;
StudentForm:any;
  constructor(private router:Router,private fb:FormBuilder ,private as: ActivatedRoute, private modalService: NgbModal,private cs:CoursesService,private ss:StudentService) { 

    this.StudentForm = this.fb.group({
      id:[''],
      });
  }
  
  ngOnInit(): void {
  
    
    this.ss.getAllStudents().subscribe(data=>this.studentList=data);

  }
  learning(){
    this.router.navigate(['my-learning']);
  }

  pay(){
    this.router.navigate(['paymentform']);
  }

  // pop(){
  //   this.router.navigate(['popup-course']);
  // }

  open(content: any) { 
    this.modalService.open(content, 
   {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => { 
      this.closeResult = `Closed with: ${result}`; 
    }, (reason) => { 
      this.closeResult =  
         `Dismissed ${this.getDismissReason(reason)}`; 
    }); 
  } 
  private getDismissReason(reason: any): string { 
    if (reason === ModalDismissReasons.ESC) { 
      return 'by pressing ESC'; 
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) { 
      return 'by clicking on a backdrop'; 
    } else { 
      return `with: ${reason}`; 
    } 
  } 
}

