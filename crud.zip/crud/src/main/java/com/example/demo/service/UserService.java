package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;

@Component("userService")
public class UserService {
	@Autowired
	private UserRepository userRepository;
	public User create(User user)			//registration
	{
		return userRepository.save(user);
	}
	public List<User> read()
	{
		return userRepository.findAll();
	}
	public User read(String email)
	{
		return userRepository.findById(email).get();
	}
	public User read(String email, String password)		//login
	{
		List<User> result = userRepository.validateLogin(email, password);
		if(result.size()==0)
			return null;
		else
			return result.get(0);
	}
	public User update(User user)
	{
		return userRepository.save(user);
	}
	public void delete(String email)
	{
		User user=read(email);
		userRepository.delete(user);
	}
}
