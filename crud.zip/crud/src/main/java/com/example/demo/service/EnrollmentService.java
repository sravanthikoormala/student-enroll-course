package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Course;
import com.example.demo.entity.Enrollment;
import com.example.demo.entity.User;
import com.example.demo.repository.EnrollmentRepository;

@Component("EnrollmentService")
public class EnrollmentService {
	@Autowired
	private EnrollmentRepository enrollmentRepository;
	public Enrollment create(Enrollment enroll)			
	{
		return enrollmentRepository.save(enroll);
	}
	public List<Enrollment> read()
	{
		return enrollmentRepository.findAll();
	}
	
	public List<Course> findCoursesByStudentId(Integer studentId)
	{
		return enrollmentRepository.findCoursesByStudentid(studentId);
	}
}
