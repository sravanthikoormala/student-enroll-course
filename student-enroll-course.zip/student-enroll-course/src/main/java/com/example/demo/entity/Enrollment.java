package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="Enrollment")
public class Enrollment {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer id;
	private Integer studentId;
	private Integer courseId;
//	@ManyToOne(fetch = FetchType.LAZY, targetEntity = Student.class)
//	@JoinColumn(name = "studentid", insertable = false, updatable = false)
//	private Student student;
//	@ManyToOne(fetch = FetchType.LAZY, targetEntity = Course.class)
//	@JoinColumn(name = "courseid", insertable = false, updatable = false)
//	private Course course;
	
	
	
	public Enrollment() {
	super();
}

	public Enrollment(Integer id, Integer studentId, Integer courseId) {
	super();
	this.id = id;
	this.studentId = studentId;
	this.courseId = courseId;
}

	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}


	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public Integer getCourseId() {
		return courseId;
	}

	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}

	@Override
	public String toString() {
		return "Enrollment [id=" + id + ", studentId=" + studentId + ", courseId=" + courseId + "]";
	}
	

	
}
