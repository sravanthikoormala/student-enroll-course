import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { CoursesService } from '../courses.service';

@Component({
  selector: 'app-my-learning',
  templateUrl: './my-learning.component.html',
  styleUrls: ['./my-learning.component.css']
})
export class MyLearningComponent implements OnInit {
  courseList:any;
  StudentId:any;
  CourseForm:any;
  coursename:any;
  constructor(private router: Router,private fb:FormBuilder, private as: ActivatedRoute, private cs: CoursesService) {
    
    this.CourseForm = this.fb.group({
      id:[''],
      name:['']

      });
   }

  ngOnInit(): void {
    this.as.queryParams.subscribe(data=>{
      this.StudentId=data.id;
      alert(this.StudentId);
    this.cs.getCoursesByStudentId(this.StudentId).subscribe(data=>this.courseList=data);

    })
    
    this.as.queryParams
    .subscribe(params => {
      console.log(params); // { order: "popular" }
      // this.courseid = params.id;
      this.CourseForm.controls.courseid.value=params.id;
      this.coursename = params.coursename;
      console.log(this.coursename); // popular
    }
    );
  }
feedback(){
  this.router.navigate(['feedback'])
}


chapter(){
  this.router.navigate(['chapter-student'])
}
}


